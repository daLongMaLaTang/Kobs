<template>
<div class="container content-field">
    <div class="card">
        <d class="card-body">
            <slot></slot>
        </d>
    </div>
</div>
</template>

<script>
</script>
<style scoped>
div.content-field{
    margin-top: 20px;
}

</style>